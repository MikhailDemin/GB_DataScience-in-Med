#ifndef CODE_sjdbInsertJunctions
#define CODE_sjdbInsertJunctions

#include "Parameters.h"
#include "Genome.h"
#include "SjdbClass.h"

void sjdbInsertJunctions(Parameters & P, Genome & mapGen, Genome & mapGen1, SjdbClass & sjdbLoci);

#endif
